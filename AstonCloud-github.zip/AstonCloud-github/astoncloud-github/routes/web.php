<?php

use App\Http\Controllers\ProjectController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/**
 * Route reference (Laravel REST pattern)
 *
 * index   -> list all projects
 * show    -> display single project
 * create  -> show create form
 * store   -> save new project
 * edit    -> show edit form
 * update  -> update project
 * destroy -> delete project
 */

/**
 * Web Routes
 *
 * Defines all routes for the application, grouped by access level.
 */

/**
 * Public routes
 *
 * Accessible to everyone, regardless of authentication state.
 */

// Homepage - displays all projects
Route::get('/', [ProjectController::class, 'index']);

/**
 * Guest routes
 *
 * Only accessible to users who are NOT authenticated.
 */
Route::middleware('guest')->group(function () {

    // Registration
    Route::get('/users/register', [UserController::class, 'create']);
    Route::post('/users', [UserController::class, 'store']);

    // Login
    Route::get('/users/login', [UserController::class, 'show'])->name('login');
    Route::post('/login', [UserController::class, 'login']);
});

/**
 * Authenticated routes
 *
 * Only accessible to logged-in users.
 */
Route::middleware('auth')->group(function () {

    // Create project
    Route::get('/projects/create', [ProjectController::class, 'create']);
    Route::post('/projects', [ProjectController::class, 'store']);

    // Manage user projects
    Route::get('/projects/manage', [ProjectController::class, 'manage']);

    // Edit project
    Route::get('/projects/{project}/edit', [ProjectController::class, 'edit']);
    Route::put('/projects/{project}', [ProjectController::class, 'update']);

    // Delete project
    Route::delete('/projects/{project}', [ProjectController::class, 'delete']);

    // Logout
    Route::post('/logout', [UserController::class, 'logout']);
});

/**
 * Project show route
 *
 * Displays a single project page (publicly accessible)
 */
Route::get('/projects/{project}', [ProjectController::class, 'show']);