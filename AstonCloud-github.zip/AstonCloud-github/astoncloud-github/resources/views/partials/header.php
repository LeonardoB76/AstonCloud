<!-- ================= HERO SECTION ================= -->
<!--
    This is the hero section of the homepage.
    It introduces the application branding and core message
    to encourage user engagement.
-->
<section class="flex flex-col items-center gap-8 sm:gap-10 mb-15 sm:mb-20 mt-30 sm:mt-40 px-5">

  <!-- ================= TEXT CONTENT ================= -->
  <!-- Contains the main message and application title -->
  <div class="text-center font-bold space-y-2 sm:space-y-4 ">

    <!-- Short motivational tagline to encourage user engagement -->
    <h3 class="text-sm sm:text-md">
      STEP FORWARD. SHARE BOLDLY. LEARN CONSISTENTLY.
    </h3>

    <!-- Second motivational heading -->
    <h2 class="text-2xl sm:text-3xl bg-linear-to-r from-fuchsia-300 to-white bg-clip-text text-transparent">
      SEIZE THE OPPORTUNITY WITH
    </h2>

    <!-- Application name -->
    <h1 class="text-5xl sm:text-8xl">
      Aston<span class="bg-linear-to-r from-blue-300 to-fuchsia-300 bg-clip-text text-transparent">Cloud</span>
    </h1>

  </div>

  <!-- ================= HERO IMAGE ================= -->
  <!-- Cloud image to enforce message, application title, and theme -->
  <div>
    <img src="/images/cloud.png" alt="cloud" class="h-15 sm:h-25 w-auto mx-auto">
  </div>

</section>