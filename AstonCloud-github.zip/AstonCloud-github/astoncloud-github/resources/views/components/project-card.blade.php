@props(['project'])

<!-- ================= PROJECT CARD COMPONENT ================= -->
<!-- 
    This component is responsible for displaying a single project card.
    It shows key project information such as title, creator, phase,
    and provides actions (edit/delete) if the authenticated user owns the project.
-->
<x-card>

    <!-- ================= PROJECT INFORMATION ================= -->
    <div class="space-y-2 sm:space-y-3">

        <!-- Project title -->
        <h3 class="font-bold text-lg sm:text-2xl">
            {{ $project->title }}
        </h3>

        <!-- Creator information (username + avatar) -->
        <div class="flex items-center gap-1 justify-center">

            <!-- Username of project owner -->
            <p class="text-sm sm:text-base">
                <span class="text-blue-300 font-bold">Creator:</span>
                {{ $project->user->username }}
            </p>

            <!-- Automatically generated avatar based on username -->
            <img 
                src="https://avatars.laravel.cloud/{{ urlencode($project->user->username) }}" 
                class="size-4 rounded-full"
                alt="avatar">
        </div>

        <!-- Project phase -->
        <p class="text-sm sm:text-base">
            <span class="text-blue-300 font-bold">Phase:</span>
            {{ $project->phase }}
        </p>

        <!-- Link to full project details page -->
        <a href="/projects/{{ $project->id }}" 
           class="text-fuchsia-300 hover:text-blue-300 text-sm sm:text-base transition-colors">
            Learn more...
        </a>

        <!-- ================= AUTHORIZED USER ACTIONS ================= -->
        <!-- Only show edit/delete if the logged-in user owns the project -->
        @if(auth()->id() === $project->user_id)

            <div class="text-sm mt-5 flex items-center justify-center gap-5 text-gray-500">

                <!-- Delete project form -->
                <form action="/projects/{{ $project->id }}" method="POST">
                    @csrf
                    @method('DELETE')

                    <button class="text-red-400 hover:text-red-500">
                        Delete <i class="bi bi-trash3-fill"></i>
                    </button>
                </form>

                <!-- Edit project link -->
                <a href="/projects/{{ $project->id }}/edit"
                   class="text-green-300 hover:text-green-500">
                    Edit <i class="bi bi-pencil-fill"></i>
                </a>

            </div>

        @endif

    </div>
</x-card>

<!-- ================= END PROJECT CARD COMPONENT ================= -->