<!-- ================= CARD COMPONENT ================= -->
<!--------------------------------------------------------------------------
This reusable Blade component is used to display content inside a styled
"card" container throughout the application.
The component uses Tailwind CSS for styling and responsiveness.
------------------------------------------------------------------------------>

<!-- Outer wrapper: creates a gradient border effect using padding and background gradient -->
<div class="w-full min-w-70 sm:min-w-100 max-w-lg p-1 rounded-3xl bg-linear-to-r from-fuchsia-300 to-blue-300">

    <!-- Inner card content container: holds the actual content passed into the component via $slot -->
    <div {{$attributes->merge([
        'class' => 'text-center rounded-3xl flex justify-center items-center gap-5 sm:gap-8 bg-gray-800 px-4 py-3 sm:py-6'
    ])}}>

        <!-- Dynamic content that comes from parent views -->
        {{ $slot }}

    </div>

</div>