@extends('layout')

@section('content')

<!-- ================= PAGE CONTAINER ================= -->
<section class="flex flex-col items-center gap-10 mt-40 mb-30 px-5">

        <!-- ================= BACK NAVIGATION ================= -->
        <!-- Returns the user to the main projects listing page -->
        <a class="font-bold text-2xl hover:text-fuchsia-300" href="/">
            <i class="hover:text-fuchsia-300 bi bi-arrow-left-circle-fill"></i>
            Back
        </a>

        <!-- ================= PROJECT DETAIL CARD ================= -->
        <!-- Reusable card component wrapping all project information -->
        <x-card class="flex flex-col items-center gap-10 sm:gap-15 py-10 sm:py-15 text-center">

            <!-- ================= PROJECT INFORMATION ================= -->
            <!-- Displays all core metadata about the selected project -->
            <div class="space-y-5 sm:space-y-8">

                <!-- Project title -->
                <h3 class="font-bold text-lg sm:text-2xl text-blue">
                    {{ $project->title }}
                </h3>

                <!-- Project timeline (start and end date) -->
                <p class="text-sm sm:text-base">
                    <span class="font-bold text-blue-300">Start date:</span> {{ $project->start_date }}
                    <i class="text-fuchsia-300 bi bi-arrow-right-circle-fill"></i>
                    <span class="font-bold text-blue-300"> End date:</span> {{ $project->end_date }}
                </p>

                <!-- ================= PROJECT OWNER INFO ================= -->
                <!-- Displays creator username and dynamically generated avatar -->
                <div class="flex items-center gap-1 justify-center">
                    <p class="text-sm sm:text-base">
                        <span class="text-blue-300 font-bold">Creator:</span>
                        {{ $project->user->username }}
                    </p>

                    <!-- Avatar generated via Laravel avatar service -->
                    <img 
                        src="https://avatars.laravel.cloud/{{ urlencode($project->user->username) }}" 
                        class="size-4 rounded-full"
                        alt="avatar">
                </div>

                <!-- User email (clickable mailto link) -->
                <p class="text-sm sm:text-base">
                    <span class="font-bold text-blue-300"> Email: </span>
                    <a class="italic text-fuchsia-300 underline"
                       href="mailto:{{ $project->user->email }}">
                        {{ $project->user->email }}
                    </a>
                </p>

                <!-- Project description -->
                <p class="text-sm sm:text-base">
                    <span class="font-bold text-blue-300"> Description:</span>
                    {{ $project->short_description }}
                </p>

                <!-- Current project phase/status -->
                <p class="text-sm sm:text-base">
                    <span class="font-bold text-blue-300">Phase:</span>
                    {{ $project->phase }}
                </p>

                <!-- GitHub repository link (only shown if available) -->
                @if (!empty($project->github_link))
                    <a href="{{ $project->github_link }}"
                       class="text-fuchsia-300 hover:text-blue-300 text-sm sm:text-base transition-colors"
                       target="_blank">
                        View on GitHub
                    </a>
                @endif

            </div>

            <!-- ================= PROJECT OWNER ACTIONS ================= -->
            <!-- Only visible to the authenticated user who owns the project -->
            @if(auth()->id() === $project->user_id)
                <div class="mt-5 flex justify-center items-center gap-6 text-gray-500">

                    <!-- Delete project form -->
                    <form action="/projects/{{ $project->id }}" method="POST">
                        @csrf
                        @method('DELETE')

                        <button class="text-red-400 hover:text-red-500">
                            Delete <i class="bi bi-trash3-fill"></i>
                        </button>
                    </form>

                    <!-- Edit project link -->
                    <a href="/projects/{{ $project->id }}/edit"
                       class="text-green-300 hover:text-green-500">
                        Edit <i class="bi bi-pencil-fill"></i>
                    </a>

                </div>
            @endif

        </x-card>
        <!-- =============== END PROJECT DETAIL CARD =============== -->   

</section>

@endsection