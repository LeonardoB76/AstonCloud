@extends('layout')

@section('content')

<!-- ================= PAGE CONTAINER ================= -->
<section class="w-full flex flex-col items-center justify-center gap-10 mt-20">

  <!-- ================= PROJECT LIST ================= -->
  <!-- Check if there are any projects to display -->
  @unless(count($projects) == 0)

    <!-- Flex container for project cards -->
    <div class="w-full flex justify-center items-center flex-wrap gap-5 sm:gap-7 mt-10">

      <!-- Loop through projects and display reusable project card component with dynamic prop data-->
      @foreach ($projects as $project)
        <x-project-card :project="$project" />
      @endforeach

    </div>

  @else

    <!-- ================= EMPTY STATE ================= -->
    <!-- Displayed when no projects exist of the user in the database -->
    <p class="font-bold text-gray-400 mt-20">
      No projects found.
      <a class="text-fuchsia-300 italic underline" href="/projects/create">
        Post your first project!
      </a>
    </p>

  @endunless

</section>

@endsection