@extends('layout')

@section('content')

<!-- ================= PAGE CONTAINER ================= -->
<section class="flex flex-col items-center gap-10 mt-40 mb-30 px-5">

    <!-- ================= BACK NAVIGATION ================= -->
    <!-- Returns user to home page (projects.index) -->
    <a class="font-bold text-2xl hover:text-fuchsia-300" href="/">
        <i class="hover:text-fuchsia-300 bi bi-arrow-left-circle-fill"></i>
        Back
    </a>

    <!-- ================= EDIT PROJECT FORM ================= -->
    <!-- Card component with a little different styling -->
    <x-card class="flex flex-col items-center gap-10 sm:gap-15 py-10 sm:py-15 text-center">

        <!-- Form submits updated project data to the update route -->
        <form class="flex flex-col items-center gap-5 w-full"
              action="/projects/{{ $project->id }}"
              method="POST"
              enctype="multipart/form-data">

            @csrf
            @method('PUT')

            <!-- ================= PROJECT TITLE ================= -->
            <label class="font-bold" for="title">Project Title:</label>
            <input class="w-full max-w-md bg-gray-700 px-2 py-2 rounded-lg focus:outline-none focus:border-2 focus:border-fuchsia-300"
                   type="text"
                   id="title"
                   name="title"
                   placeholder="Project Title"
                   value="{{ old('title', $project->title) }}"
                   required>
            @error('title')
                <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
            @enderror

            <!-- ================= START DATE ================= -->
            <label class="font-bold" for="start_date">Start Date:</label>
            <input class="w-full max-w-50 bg-gray-700 px-2 py-2 rounded-lg focus:outline-none focus:border-2 focus:border-fuchsia-300"
                   type="date"
                   id="start_date"
                   name="start_date"
                   value="{{ old('start_date', $project->start_date) }}"
                   required>
            @error('start_date')
                <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
            @enderror


            <!-- ================= END DATE ================= -->
            <label class="font-bold" for="end_date">End Date:</label>
            <input class="w-full max-w-50 bg-gray-700 px-2 py-2 rounded-lg focus:outline-none focus:border-2 focus:border-fuchsia-300"
                   type="date"
                   id="end_date"
                   name="end_date"
                   value="{{ old('end_date', $project->end_date) }}"
                   required>
            @error('end_date')
                <p class="text-sm text-red-600">{{ $message }}</p>
            @enderror


            <!-- ================= SHORT DESCRIPTION ================= -->
            <label class="font-bold" for="short_description">Short Description:</label>
            <textarea class="w-full max-w-md bg-gray-700 px-2 py-2 rounded-lg focus:outline-none focus:border-2 focus:border-fuchsia-300"
                      id="short_description"
                      name="short_description"
                      placeholder="Short Description"
                      required>{{ old('short_description', $project->short_description) }}</textarea>
            @error('short_description')
                <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
            @enderror


            <!-- ================= PROJECT PHASE ================= -->
            <label class="font-bold" for="phase">Phase:</label>
            <select class="w-full max-w-md bg-gray-700 px-2 py-2 rounded-lg focus:outline-none focus:border-2 focus:border-fuchsia-300"
                    id="phase"
                    name="phase"
                    placeholder="Phase"
                    required>

                <option value="">Choose a phase</option>

                <option value="design" @selected(old('phase', $project->phase) == 'design')>Design</option>
                <option value="development" @selected(old('phase', $project->phase) == 'development')>Development</option>
                <option value="testing" @selected(old('phase', $project->phase) == 'testing')>Testing</option>
                <option value="deployment" @selected(old('phase', $project->phase) == 'deployment')>Deployment</option>
                <option value="complete" @selected(old('phase', $project->phase) == 'complete')>Complete</option>

            </select>
            @error('phase')
                <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
            @enderror

            <!-- ================= GITHUB LINK ================= -->
            <label class="font-bold" for="github_link">GitHub Link:</label>
            <input class="w-full max-w-md bg-gray-700 px-2 py-2 rounded-lg focus:outline-none focus:border-2 focus:border-fuchsia-300"
                   type="url"
                   id="github_link"
                   name="github_link"
                   placeholder="GitHub Link"
                   value="{{ old('github_link', $project->github_link) }}"
                   pattern="https://github\.com/.+/.+">
            @error('github_link')
                <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
            @enderror

            <!-- ================= SUBMIT BUTTON ================= -->
            <button class="mt-5 px-3 sm:px-7 py-1 sm:py-2 rounded-xl border-3 border-fuchsia-300 font-bold bg-gray-600 hover:bg-fuchsia-300 hover:text-gray-800 transition-colors"
                    type="submit">
                Edit
            </button>

        </form>
    </x-card>
    <!-- =============== END EDIT PROJECT FORM =============== -->

</section>

@endsection