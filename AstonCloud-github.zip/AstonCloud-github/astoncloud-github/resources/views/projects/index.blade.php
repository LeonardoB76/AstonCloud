@extends('layout')

@section('content')

<!-- ================= HEADER INCLUDE ================= -->
<!-- Shared header partial -->
@include('partials.header')

<!-- ================= MAIN PAGE CONTAINER ================= -->
<section class="flex flex-col items-center gap-3 sm:gap-8 mt-12 px-5 sm:px-10 py-2 sm:py-10 space-y-10">

  <!-- ================= PAGE HEADER ================= -->
  <div class="space-y-5 px-3">

    <!-- Page title / intro text -->
    <h2 class="text-lg sm:text-2xl text-center bg-linear-to-r from-fuchsia-300 to-white bg-clip-text text-transparent">
      SEE WHAT PROJECTS OTHERS HAVE SHARED...
    </h2>

    <!-- ================= SEARCH FORM ================= -->
    <!-- Sends GET request to filter projects using query string -->
    <form action="/" method="GET">
      <input 
        type="text"
        name="search"
        placeholder="Search..."
        class="w-full max-w-md sm:max-w-lg px-4 py-2 rounded-lg bg-gray-800 focus:outline-none focus:border-2 focus:border-fuchsia-300"
      >
    </form>

  </div>

  <!-- ================= PROJECT LIST ================= -->

  <!-- If projects exist, show them -->
  @unless(count($projects) == 0)

    <div class="flex justify-center items-center flex-wrap gap-5 sm:gap-7">

      <!-- Loop through each project and show project card component -->
      @foreach ($projects as $project)
        <x-project-card :project="$project" />
      @endforeach

    </div>

  @else

    <!-- ================= EMPTY STATE ================= -->
    <!-- Shown when no projects match query or database is empty -->
    <p class="font-bold text-gray-400 mt-10 sm:mt-20 text-center">
      No projects found.
      <a class="text-fuchsia-300 italic underline" href="/projects/create">
        Be the first to post a project!
      </a>
    </p>

  @endunless

  <!-- ================= PAGINATION ================= -->
  <!-- Laravel pagination links for navigating project pages -->
  <div class="w-full">
    {{ $projects->links() }}
  </div>

</section>

@endsection