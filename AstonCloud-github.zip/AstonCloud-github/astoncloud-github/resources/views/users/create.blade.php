@extends('layout')

@section('content')

<!-- ================= PAGE CONTAINER ================= -->
<section class="flex flex-col items-center gap-10 mt-40 mb-30 px-5">

    <!-- ================= BACK BUTTON ================= -->
    <!-- Navigates user back to home (project.index) -->
    <a class="font-bold text-2xl hover:text-fuchsia-300" href="/">
        <i class="hover:text-fuchsia-300 bi bi-arrow-left-circle-fill"></i>
        Back
    </a>

    <!-- ================= REGISTER FORM ================= -->
    <!-- User registration form (creates new user) -->
    <x-card class="flex flex-col items-center gap-10 sm:gap-15 py-10 sm:py-15 text-center">

        <form class="flex flex-col items-center gap-5 w-full"
              action="/users"
              method="POST">

            @csrf

            <!-- ================= USERNAME ================= -->
            <label class="font-bold" for="username">Create username:</label>
            <input class="w-full max-w-md bg-gray-700 px-2 py-2 rounded-lg focus:outline-none focus:border-2 focus:border-fuchsia-300"
                type="text"
                id="username"
                name="username"
                placeholder="Username"
                value="{{ old('username') }}"
                required>

            @error('username')
                <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
            @enderror

            <!-- ================= EMAIL ================= -->
            <label class="font-bold" for="email">Email:</label>
            <input class="w-full max-w-md bg-gray-700 px-2 py-2 rounded-lg focus:outline-none focus:border-2 focus:border-fuchsia-300"
                type="email"
                id="email"
                name="email"
                placeholder="Email"
                value="{{ old('email') }}"
                required>

            @error('email')
                <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
            @enderror

            <!-- ================= PASSWORD ================= -->
            <label class="font-bold" for="password">Password:</label>
            <input class="w-full max-w-md bg-gray-700 px-2 py-2 rounded-lg focus:outline-none focus:border-2 focus:border-fuchsia-300"
                type="password"
                id="password"
                name="password"
                placeholder="Password"
                required>

            @error('password')
                <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
            @enderror

            <!-- ================= PASSWORD CONFIRMATION ================= -->
            <label class="font-bold" for="password_confirmation">Confirm Password:</label>
            <input class="w-full max-w-md bg-gray-700 px-2 py-2 rounded-lg focus:outline-none focus:border-2 focus:border-fuchsia-300"
                type="password"
                id="password_confirmation"
                name="password_confirmation"
                placeholder="Confirm Password"
                required>

            <!-- Laravel handles confirmation validation automatically -->

            <!-- ================= SUBMIT BUTTON ================= -->
            <button class="mt-5 px-2 sm:px-4 py-1 sm:py-2 rounded-xl border-3 border-fuchsia-300 font-bold bg-gray-600 hover:bg-fuchsia-300 hover:text-gray-800 transition-colors"
                type="submit">
                Register
            </button>

        </form>

    </x-card>
    <!-- =============== END REGISTER FORM =============== -->

</section>

@endsection