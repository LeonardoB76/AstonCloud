@extends('layout')

@section('content')

<!-- ================= PAGE CONTAINER ================= -->
<section class="flex flex-col items-center gap-10 mt-40 mb-30 px-5">

    <!-- ================= BACK BUTTON ================= -->
    <!-- Navigates user back to home (projects.index) -->
    <a class="font-bold text-2xl hover:text-fuchsia-300" href="/">
        <i class="hover:text-fuchsia-300 bi bi-arrow-left-circle-fill"></i>
        Back
    </a>

    <!-- ================= LOGIN FORM ================= -->
    <!-- Authenticates existing user and starts session -->
    <x-card class="flex flex-col items-center gap-10 sm:gap-15 py-10 sm:py-15 text-center">

        <form class="flex flex-col items-center gap-5 w-full"
              action="/login"
              method="POST">

            @csrf

            <!-- ================= USERNAME FIELD ================= -->
            <label class="font-bold" for="username">Username:</label>
            <input
                class="w-full max-w-md bg-gray-700 px-2 py-2 rounded-lg focus:outline-none focus:border-2 focus:border-fuchsia-300"
                type="text"
                id="username"
                name="username"
                placeholder="Username"
                value="{{ old('username') }}"
                required>

            @error('username')
                <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
            @enderror

            <!-- ================= PASSWORD FIELD ================= -->
            <label class="font-bold" for="password">Password:</label>
            <input
                class="w-full max-w-md bg-gray-700 px-2 py-2 rounded-lg focus:outline-none focus:border-2 focus:border-fuchsia-300"
                type="password"
                id="password"
                name="password"
                placeholder="Password"
                required>

            @error('password')
                <p class="text-sm text-red-600 mt-1">{{ $message }}</p>
            @enderror

            <!-- ================= SUBMIT BUTTON ================= -->
            <button
                class="mt-5 px-2 sm:px-4 py-1 sm:py-2 rounded-xl border-3 border-fuchsia-300 font-bold bg-gray-600 hover:bg-fuchsia-300 hover:text-gray-800 transition-colors"
                type="submit">
                Login
            </button>

            <!-- ================= REGISTER REDIRECT ================= -->
            <!-- Redirect for users who do not have an account to register route -->
            <p class="mt-3">
                No Account?
                <a class="text-fuchsia-300" href="/users/register">Register</a>
            </p>

        </form>

    </x-card>
    <!-- =============== END LOGIN FORM =============== -->

</section>

@endsection