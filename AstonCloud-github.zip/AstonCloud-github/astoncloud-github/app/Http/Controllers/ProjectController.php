<?php

namespace App\Http\Controllers;

use App\Models\Project;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

/**
 * ProjectController
 *
 * Handles all CRUD operations for projects.
 * Includes authentication-based authorization to ensure
 * users can only manage their own projects.
 *
 * Resource Routes:
 * index   → display all projects
 * show    → display a single project
 * create  → show form to create a project
 * store   → store a new project
 * edit    → show edit form
 * update  → update existing project
 * delete  → delete a project
 */
class ProjectController extends Controller
{
    /**
     * Display a paginated list of projects.
     * Includes optional search filtering.
     */
    public function index()
    {
        return view('projects.index', [
            'projects' => Project::latest()
                ->filter(request(['search']))
                ->simplePaginate(9)
        ]);
    }

    /**
     * Display a single project.
     *
     * @param Project $project (route model binding)
     */
    public function show(Project $project)
    {
        return view('projects.show', [
            'project' => $project
        ]);
    }

    /**
     * Show the form to create a new project.
     */
    public function create()
    {
        return view('projects.create');
    }

    /**
     * Store a created project in the database.
     * Validates input and associates project with authenticated user.
     */
    public function store(Request $request)
    {
        $formFields = $request->validate([
            'title' => 'required|string|max:255|unique:projects,title',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'short_description' => 'required|string|max:1000',
            'phase' => 'required|in:design,development,testing,deployment,complete',
            'github_link' => [
                'nullable',
                'url',
                'regex:/^https:\/\/(www\.)?github\.com\/[^\/]+\/[^\/]+\/?$/'
            ]
        ]);

        // Attach authenticated user id to the project
        $formFields['user_id'] = auth()->id();

        Project::create($formFields);

        return redirect('/')
            ->with('success', 'Project has been posted successfully!');
    }

    /**
     * Display all projects belonging to the authenticated user.
     * Used for "Manage Projects" page.
     */
    public function manage()
    {
        $projects = Project::where('user_id', auth()->id())->get();

        return view('projects.manage', [
            'projects' => $projects
        ]);
    }

    /**
     * Show the edit form for a specific project.
     * Ensures only the owner can access it.
     */
    public function edit(Project $project)
    {
        if ($project->user_id !== auth()->id()) {
            abort(403, 'Unauthorized access');
        }

        return view('projects.edit', [
            'project' => $project
        ]);
    }

    /**
     * Update an existing project.
     * Includes validation and ownership check.
     */
    public function update(Request $request, Project $project)
    {
        // Authorization check
        if ($project->user_id !== auth()->id()) {
            abort(403, 'Unauthorized access');
        }

        $formFields = $request->validate([
            'title' => [
                'required',
                'string',
                'max:255',
                // Ignore current project when checking uniqueness
                Rule::unique('projects', 'title')->ignore($project->id)
            ],
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'short_description' => 'required|string|max:1000',
            'phase' => 'required|in:design,development,testing,deployment,complete',
            'github_link' => [
                'nullable',
                'url',
                'regex:/^https:\/\/(www\.)?github\.com\/[^\/]+\/[^\/]+\/?$/'
            ]
        ]);

        $project->update($formFields);

        return redirect('/')
            ->with('success', 'Project has been updated successfully');
    }

    /**
     * Delete a project.
     * Only the user that created the project is authorized to perform this action.
     */
    public function delete(Project $project)
    {
        if ($project->user_id !== auth()->id()) {
            abort(403, 'Unauthorized access');
        }

        $project->delete();

        return redirect('/')
            ->with('success', 'Project has been deleted successfully');
    }
}