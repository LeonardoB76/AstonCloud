<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

/**
 * UserController
 *
 * Handles user authentication and registration:
 * Registration (create/store)
 * Login (show/login)
 * Logout
 *
 * Uses Laravel's built-in authentication system.
 */
class UserController extends Controller
{
    /**
     * Show the registration form.
     */
    public function create()
    {
        return view('users.create');
    }

    /**
     * Store a newly registered user.
     * Validates input, hashes password, logs user in automatically.
     */
    public function store(Request $request)
    {
        $formFields = $request->validate([
            'username' => 'required|string|min:3|max:50|unique:users,username',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|confirmed|min:8',
        ]);

        // Securely hash the password before saving to database
        $formFields['password'] = bcrypt($formFields['password']);

        // Create new user record
        $user = User::create($formFields);

        // Automatically log in the newly registered user
        auth()->login($user);

        return redirect('/')
            ->with('success', 'Thank you for registering ' . auth()->user()->username . ', you are now logged in.');
    }

    /**
     * Log the user out of the application.
     * Invalidates session and regenerates CSRF token for security.
     */
    public function logout(Request $request)
    {
        auth()->logout();

        // Invalidate the current session
        $request->session()->invalidate();

        // Regenerate CSRF token to prevent token reuse
        $request->session()->regenerateToken();

        return redirect('/')
            ->with('success', 'You have been logged out.');
    }

    /**
     * Show the login form.
     */
    public function show()
    {
        return view('users.show-login');
    }

    /**
     * Handle user login.
     * Validates credentials and attempts authentication.
     */
    public function login(Request $request)
    {
        $formFields = $request->validate([
            'username' => 'required',
            'password' => 'required',
        ]);

        // Attempt to authenticate user with provided credentials
        if (auth()->attempt($formFields)) {

            // Regenerate session to prevent session fixation attacks
            $request->session()->regenerate();

            return redirect('/')
                ->with('success', 'You have been logged in ' . auth()->user()->username . '.');
        }

        // If authentication failed return error message
        return back()
            ->withErrors(['username' => 'Incorrect username or password'])
            ->onlyInput('username');
    }
}