<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Project Model
 *
 * Represents a project entity in the application.
 * Handles relationship with User model, which attributes can be seeded, and query filtering.
 */
class Project extends Model
{
    use HasFactory;

    /**
     * Defines which fields can be mass-assigned.
     */
    protected $fillable = [
        'title',
        'start_date',
        'end_date',
        'short_description',
        'phase',
        'github_link',
        'user_id'
    ];

    /**
     * Scope: Filter projects based on search input.
     *
     * Allows searching across:
     * Project fields (title, dates, description, phase, GitHub link)
     * Related user fields (username and email)
     *
     * Uses a grouped query to ensure correct SQL logic.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @param array $filters
     * @return void
     */
    public function scopeFilter($query, $filters)
    {
        if ($filters['search'] ?? false) {

            $search = $filters['search'];

            $query->where(function ($q) use ($search) {

                // Search within project attributes
                $q->where('title', 'like', '%' . $search . '%')
                  ->orWhere('start_date', 'like', '%' . $search . '%')
                  ->orWhere('end_date', 'like', '%' . $search . '%')
                  ->orWhere('short_description', 'like', '%' . $search . '%')
                  ->orWhere('phase', 'like', '%' . $search . '%')
                  ->orWhere('github_link', 'like', '%' . $search . '%')

                  // Search within related user (relationship query)
                  ->orWhereHas('user', function ($q) use ($search) {
                      $q->where('username', 'like', '%' . $search . '%')
                        ->orWhere('email', 'like', '%' . $search . '%');
                  });
            });
        }
    }

    /**
     * Relationship: project belongs to a user.
     * One user has many projects.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}