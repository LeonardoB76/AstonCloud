<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Attributes\Hidden;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

/**
 * User Model
 *
 * Represents an authenticated user of the system.
 * Extends Laravel's Authenticatable class to provide
 * built-in authentication functionality.
 *
 * Handles:
 * - Defines which fields can be mass-assigned
 * - Attribute hiding (security)
 * - Relationship with projects
 */

/**
 * These two lines are added by Laravel by default. 
 * The 'Fillable' array is used to decalre to Laravel which fields can be mass-assigned.
 * The 'Hidden' array is used to hide 'password' and 'remember_token'
 * in the case the model is converted to arrays or JSON.
 */
#[Fillable(['username', 'email', 'password'])]
#[Hidden(['password', 'remember_token'])]

class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasFactory, Notifiable;

    /**
     * Relationship: User has many projects.
     * One user has multiple projects.
     */
    public function projects()
    {
        return $this->hasMany(Project::class);
    }
}