<?php

namespace Database\Factories;

use App\Models\Project;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * Factory class used to generate fake Project data
 * for testing and database seeding.
 *
 * @extends Factory<Project>
 */
class ProjectFactory extends Factory
{
    /**
     * Generates realistic dummy data for a project.
     *
     * NOTE:
     *   user_id is NOT included here because it is automatically
     *   assigned when using relationships like:
     *   User::factory()->hasProjects() (see DataBaseSeeder.php)
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'title' => fake()->sentence(3),

            'start_date' => fake()
                ->dateTimeBetween('-2 months', 'now')
                ->format('Y-m-d'),

            'end_date' => fake()
                ->dateTimeBetween('now', '+2 months')
                ->format('Y-m-d'),

            'short_description' => fake()->paragraph(2),

            'phase' => fake()->randomElement([
                'design',
                'development',
                'testing',
                'deployment',
                'complete'
            ]),

            'github_link' => fake()->optional()->url(),
        ];
    }
}