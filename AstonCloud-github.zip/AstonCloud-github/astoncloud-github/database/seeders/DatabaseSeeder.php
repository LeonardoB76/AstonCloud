<?php

namespace Database\Seeders;

use App\Models\Project;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

/**
 * Database Seeder
 *
 * Responsible for populating the database with dummy data.
 */
class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     *
     * Creates multiple users and automatically assigns
     * each user a set of related projects using model factories.
     */
    public function run(): void
    {
        /**
         * Creates 5 users with associated projects.
         *
         * Each user is generated using UserFactory
         * Each user is assigned 5 projects using the hasProjects() relationship
         */
        User::factory(5)
            ->hasProjects(5)
            ->create();
    }
}