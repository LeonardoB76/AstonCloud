<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Migration: Create Projects Table
 *
 * This table stores all project data created by users.
 * Each project is linked to a specific user via a foreign key relationship.
 */
return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * Creates the "projects" table with all required fields
     * for storing project details and ownership information.
     */
    public function up(): void
    {
        Schema::create('projects', function (Blueprint $table) {

            // Primary key (equivalent to 'pid' in assignment specification)
            $table->id();

            // Project title (name of the project)
            $table->string('title');

            // Project start date
            $table->date('start_date');

            // Project end date
            $table->date('end_date');

            // Detailed description of the project
            $table->text('short_description');

            /**
             * Project phase status.
             * Restricts values to predefined workflow stages.
             */
            $table->enum('phase', [
                'design',
                'development',
                'testing',
                'deployment',
                'complete'
            ]);

            //  GitHub repository link
            $table->string('github_link')->nullable();

            /**
             * Foreign key linking project to a user.
             * - Ensures each project belongs to a user
             * - Cascade delete removes projects if user is deleted
             */
            $table->foreignId('user_id')
                ->constrained()
                ->onDelete('cascade');

            // Automatically managed timestamps (created_at, updated_at)
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('projects');
    }
};