<?php $__env->startSection('content'); ?>

<!-- ================= PAGE CONTAINER ================= -->
<section class="w-full flex flex-col items-center justify-center gap-10 mt-20">

  <!-- ================= PROJECT LIST ================= -->
  <!-- Check if there are any projects to display -->
  <?php if (! (count($projects) == 0)): ?>

    <!-- Flex container for project cards -->
    <div class="w-full flex justify-center items-center flex-wrap gap-5 sm:gap-7 mt-10">

      <!-- Loop through projects and display reusable project card component with dynamic prop data-->
      <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if (isset($component)) { $__componentOriginaldbcceabf4a99a34f9999233ae1fef693 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldbcceabf4a99a34f9999233ae1fef693 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.project-card','data' => ['project' => $project]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('project-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['project' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($project)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldbcceabf4a99a34f9999233ae1fef693)): ?>
<?php $attributes = $__attributesOriginaldbcceabf4a99a34f9999233ae1fef693; ?>
<?php unset($__attributesOriginaldbcceabf4a99a34f9999233ae1fef693); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldbcceabf4a99a34f9999233ae1fef693)): ?>
<?php $component = $__componentOriginaldbcceabf4a99a34f9999233ae1fef693; ?>
<?php unset($__componentOriginaldbcceabf4a99a34f9999233ae1fef693); ?>
<?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

  <?php else: ?>

    <!-- ================= EMPTY STATE ================= -->
    <!-- Displayed when no projects exist of the user in the database -->
    <p class="font-bold text-gray-400 mt-20">
      No projects found.
      <a class="text-fuchsia-300 italic underline" href="/projects/create">
        Post your first project!
      </a>
    </p>

  <?php endif; ?>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/leonardobusato/Documents/final-backend-website/astoncloud/resources/views/projects/manage.blade.php ENDPATH**/ ?>