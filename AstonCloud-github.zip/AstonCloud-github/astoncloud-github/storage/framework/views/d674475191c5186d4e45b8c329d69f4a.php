<?php if($paginator->hasPages()): ?>
    <nav role="navigation" aria-label="<?php echo e(__('Pagination Navigation')); ?>" class="flex gap-5 items-center justify-center">

        <?php if($paginator->onFirstPage()): ?>
            <span class="inline-flex items-center px-4 py-2 text-sm font-bold text-white bg-gray-700 border-2 border-fuchsia-300 rounded-md opacity-50 cursor-not-allowed">
                <?php echo __('pagination.previous'); ?>

            </span>
        <?php else: ?>
            <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev"
               class="inline-flex items-center px-4 py-2 text-sm font-bold text-white bg-gray-700 border-2 border-fuchsia-300 rounded-md hover:text-gray-700 hover:bg-fuchsia-300 transition">
                <?php echo __('pagination.previous'); ?>

            </a>
        <?php endif; ?>

        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next"
               class="inline-flex items-center px-4 py-2 text-sm font-bold text-white bg-gray-700 border-2 border-fuchsia-300 rounded-md hover:text-gray-700 hover:bg-fuchsia-300 transition">
                <?php echo __('pagination.next'); ?>

            </a>
        <?php else: ?>
            <span class="inline-flex items-center px-4 py-2 text-sm font-bold text-white bg-gray-700 border-2 border-fuchsia-300 rounded-md opacity-50 cursor-not-allowed">
                <?php echo __('pagination.next'); ?>

            </span>
        <?php endif; ?>

    </nav>
<?php endif; ?><?php /**PATH /Users/leonardobusato/Documents/AstonCloud-final/astoncloud/resources/views/vendor/pagination/simple-tailwind.blade.php ENDPATH**/ ?>