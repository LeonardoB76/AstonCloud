<?php $__env->startSection('content'); ?>

    <section class="flex flex-col items-center gap-10 mt-40 mb-30 px-5">

        <!-- Back button-->

        <a class="font-bold text-2xl hover:text-fuchsia-300" href="/"> <i class="hover:text-fuchsia-300 bi bi-arrow-left-circle-fill"></i> Back</a>

        <!-- ================= LOGIN FORM ================= -->
        <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['class' => 'flex flex-col items-center gap-10 sm:gap-15 py-10 sm:py-15 text-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'flex flex-col items-center gap-10 sm:gap-15 py-10 sm:py-15 text-center']); ?>
            <form class="flex flex-col items-center gap-5 w-full" action="/login" method="POST">

                <?php echo csrf_field(); ?>

                <label class="font-bold" for="username">Username:</label>
                <input
                    class="w-full max-w-md bg-gray-700 px-2 py-2 rounded-lg focus:outline-none focus:border-2 focus:border-fuchsia-300"
                    type="text"
                    id="username"
                    name="username"
                    placeholder="Username"
                    value="<?php echo e(old('username')); ?>"
                    required>
                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                <label class="font-bold" for="password">Password:</label>
                <input
                    class="w-full max-w-md bg-gray-700 px-2 py-2 rounded-lg focus:outline-none focus:border-2 focus:border-fuchsia-300"
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Password"
                    required>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                <button
                    class="font-bold text-md sm:text-lg px-3 py-2 rounded-2xl border-5 border-fuchsia-300 bg-gray-600 hover:bg-blue-500 transition-colors mt-10"
                    type="submit">
                    Login
                </button>

                <p class="mt-3">No Account? <a class="text-fuchsia-300" href="/users/register">Register</a> </p>

            </form>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
        <!-- =============== END LOGIN FORM =============== -->   

        </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/leonardobusato/Documents/final-backend-website/astoncloud/resources/views/users/show.blade.php ENDPATH**/ ?>