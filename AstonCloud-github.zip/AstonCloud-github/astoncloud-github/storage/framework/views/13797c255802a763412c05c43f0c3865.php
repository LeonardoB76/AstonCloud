<?php $__env->startSection('content'); ?>

<!-- ================= HEADER INCLUDE ================= -->
<!-- Shared header partial -->
<?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<!-- ================= MAIN PAGE CONTAINER ================= -->
<section class="flex flex-col items-center gap-3 sm:gap-8 mt-12 px-5 sm:px-10 py-2 sm:py-10 space-y-10">

  <!-- ================= PAGE HEADER ================= -->
  <div class="space-y-5 px-3">

    <!-- Page title / intro text -->
    <h2 class="text-lg sm:text-2xl text-center bg-linear-to-r from-fuchsia-300 to-white bg-clip-text text-transparent">
      SEE WHAT PROJECTS OTHERS HAVE SHARED...
    </h2>

    <!-- ================= SEARCH FORM ================= -->
    <!-- Sends GET request to filter projects using query string -->
    <form action="/" method="GET">
      <input 
        type="text"
        name="search"
        placeholder="Search..."
        class="w-full max-w-md sm:max-w-lg px-4 py-2 rounded-lg bg-gray-800 focus:outline-none focus:border-2 focus:border-fuchsia-300"
      >
    </form>

  </div>

  <!-- ================= PROJECT LIST ================= -->

  <!-- If projects exist, show them -->
  <?php if (! (count($projects) == 0)): ?>

    <div class="flex justify-center items-center flex-wrap gap-5 sm:gap-7">

      <!-- Loop through each project and show project card component -->
      <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if (isset($component)) { $__componentOriginaldbcceabf4a99a34f9999233ae1fef693 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldbcceabf4a99a34f9999233ae1fef693 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.project-card','data' => ['project' => $project]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('project-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['project' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($project)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldbcceabf4a99a34f9999233ae1fef693)): ?>
<?php $attributes = $__attributesOriginaldbcceabf4a99a34f9999233ae1fef693; ?>
<?php unset($__attributesOriginaldbcceabf4a99a34f9999233ae1fef693); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldbcceabf4a99a34f9999233ae1fef693)): ?>
<?php $component = $__componentOriginaldbcceabf4a99a34f9999233ae1fef693; ?>
<?php unset($__componentOriginaldbcceabf4a99a34f9999233ae1fef693); ?>
<?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

  <?php else: ?>

    <!-- ================= EMPTY STATE ================= -->
    <!-- Shown when no projects match query or database is empty -->
    <p class="font-bold text-gray-400 mt-10 sm:mt-20 text-center">
      No projects found.
      <a class="text-fuchsia-300 italic underline" href="/projects/create">
        Be the first to post a project!
      </a>
    </p>

  <?php endif; ?>

  <!-- ================= PAGINATION ================= -->
  <!-- Laravel pagination links for navigating project pages -->
  <div class="w-full">
    <?php echo e($projects->links()); ?>

  </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/leonardobusato/Documents/final-backend-website/astoncloud/resources/views/projects/index.blade.php ENDPATH**/ ?>