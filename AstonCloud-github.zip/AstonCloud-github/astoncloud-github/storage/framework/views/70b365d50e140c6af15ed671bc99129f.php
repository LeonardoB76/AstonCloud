<?php $__env->startSection('content'); ?>

<!-- ================= PAGE CONTAINER ================= -->
<section class="flex flex-col items-center gap-10 mt-40 mb-30 px-5">

    <!-- ================= BACK NAVIGATION ================= -->
    <!-- Returns user to the main projects listing page -->
    <a class="font-bold text-2xl hover:text-fuchsia-300" href="/">
        <i class="hover:text-fuchsia-300 bi bi-arrow-left-circle-fill"></i>
        Back
    </a>

    <!-- ================= CREATE PROJECT FORM ================= -->
    <!-- Card component -->
    <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['class' => 'flex flex-col items-center gap-10 sm:gap-15 py-10 sm:py-15 text-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'flex flex-col items-center gap-10 sm:gap-15 py-10 sm:py-15 text-center']); ?>

        <!-- Form submits new project data to the store route -->
        <form class="flex flex-col items-center gap-5 w-full" action="/projects" method="POST">
            <?php echo csrf_field(); ?>

            <!-- ================= PROJECT TITLE ================= -->
            <label class="font-bold" for="title">Project Title:</label>
            <input class="w-full max-w-md bg-gray-700 px-2 py-2 rounded-lg focus:outline-none focus:border-2 focus:border-fuchsia-300"
                   type="text"
                   id="title"
                   name="title"
                   placeholder="Project Title"
                   required
                   value="<?php echo e(old('title')); ?>">
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <!-- ================= START DATE ================= -->
            <label class="font-bold" for="start_date">Start Date:</label>
            <input class="w-full max-w-50 bg-gray-700 px-2 py-2 rounded-lg focus:outline-none focus:border-2 focus:border-fuchsia-300"
                   type="date"
                   id="start_date"
                   name="start_date"
                   required
                   value="<?php echo e(old('start_date')); ?>">
            <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <!-- ================= END DATE ================= -->
            <label class="font-bold" for="end_date">End Date:</label>
            <input class="w-full max-w-50 bg-gray-700 px-2 py-2 rounded-lg focus:outline-none focus:border-2 focus:border-fuchsia-300"
                   type="date"
                   id="end_date"
                   name="end_date"
                   required
                   value="<?php echo e(old('end_date')); ?>">
            <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <!-- ================= SHORT DESCRIPTION ================= -->
            <label class="font-bold" for="short_description">Short Description:</label>
            <textarea class="w-full max-w-md bg-gray-700 px-2 py-2 rounded-lg focus:outline-none focus:border-2 focus:border-fuchsia-300"
                      id="short_description"
                      name="short_description"
                      placeholder="Description"
                      required><?php echo e(old('short_description')); ?></textarea>
            <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <!-- ================= PROJECT PHASE ================= -->
            <label class="font-bold" for="phase">Phase:</label>
            <select class="w-full max-w-md bg-gray-700 px-2 py-2 rounded-lg focus:outline-none focus:border-2 focus:border-fuchsia-300"
                    id="phase"
                    name="phase"
                    required>

                <option value="">Choose a phase</option>
                <option value="design" <?php if(old('phase') == 'design'): echo 'selected'; endif; ?>>Design</option>
                <option value="development" <?php if(old('phase') == 'development'): echo 'selected'; endif; ?>>Development</option>
                <option value="testing" <?php if(old('phase') == 'testing'): echo 'selected'; endif; ?>>Testing</option>
                <option value="deployment" <?php if(old('phase') == 'deployment'): echo 'selected'; endif; ?>>Deployment</option>
                <option value="complete" <?php if(old('phase') == 'complete'): echo 'selected'; endif; ?>>Complete</option>

            </select>
            <?php $__errorArgs = ['phase'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <!-- ================= GITHUB LINK ================= -->
            <label class="font-bold" for="github_link">GitHub Link:</label>
            <input class="w-full max-w-md bg-gray-700 px-2 py-2 rounded-lg focus:outline-none focus:border-2 focus:border-fuchsia-300"
                   type="url"
                   id="github_link"
                   name="github_link"
                   pattern="https://github\.com/.+/.+"
                   placeholder="https://github.com/username/repository"
                   value="<?php echo e(old('github_link')); ?>">
            <?php $__errorArgs = ['github_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <!-- ================= SUBMIT BUTTON ================= -->
            <button class="mt-5 px-3 sm:px-7 py-1 sm:py-2 rounded-xl border-3 border-fuchsia-300 font-bold bg-gray-600 hover:bg-fuchsia-300 hover:text-gray-800 transition-colors"
                    type="submit">
                Post
            </button>

        </form>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
    <!-- =============== END CREATE PROJECT FORM =============== -->

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/leonardobusato/Documents/AstonCloud-final/astoncloud/resources/views/projects/create.blade.php ENDPATH**/ ?>