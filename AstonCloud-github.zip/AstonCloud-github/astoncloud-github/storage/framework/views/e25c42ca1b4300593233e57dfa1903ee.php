<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['project']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['project']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<!-- ================= PROJECT CARD COMPONENT ================= -->
<!-- 
    This component is responsible for displaying a single project card.
    It shows key project information such as title, creator, phase,
    and provides actions (edit/delete) if the authenticated user owns the project.
-->
<?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <!-- ================= PROJECT INFORMATION ================= -->
    <div class="space-y-2 sm:space-y-3">

        <!-- Project title -->
        <h3 class="font-bold text-lg sm:text-2xl">
            <?php echo e($project->title); ?>

        </h3>

        <!-- Creator information (username + avatar) -->
        <div class="flex items-center gap-1 justify-center">

            <!-- Username of project owner -->
            <p class="text-sm sm:text-base">
                <span class="text-blue-300 font-bold">Creator:</span>
                <?php echo e($project->user->username); ?>

            </p>

            <!-- Automatically generated avatar based on username -->
            <img 
                src="https://avatars.laravel.cloud/<?php echo e(urlencode($project->user->username)); ?>" 
                class="size-4 rounded-full"
                alt="avatar">
        </div>

        <!-- Project phase -->
        <p class="text-sm sm:text-base">
            <span class="text-blue-300 font-bold">Phase:</span>
            <?php echo e($project->phase); ?>

        </p>

        <!-- Link to full project details page -->
        <a href="/projects/<?php echo e($project->id); ?>" 
           class="text-fuchsia-300 hover:text-blue-300 text-sm sm:text-base transition-colors">
            Learn more...
        </a>

        <!-- ================= AUTHORIZED USER ACTIONS ================= -->
        <!-- Only show edit/delete if the logged-in user owns the project -->
        <?php if(auth()->id() === $project->user_id): ?>

            <div class="text-sm mt-5 flex items-center justify-center gap-5 text-gray-500">

                <!-- Delete project form -->
                <form action="/projects/<?php echo e($project->id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>

                    <button class="text-red-400 hover:text-red-500">
                        Delete <i class="bi bi-trash3-fill"></i>
                    </button>
                </form>

                <!-- Edit project link -->
                <a href="/projects/<?php echo e($project->id); ?>/edit"
                   class="text-green-300 hover:text-green-500">
                    Edit <i class="bi bi-pencil-fill"></i>
                </a>

            </div>

        <?php endif; ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>

<!-- ================= END PROJECT CARD COMPONENT ================= --><?php /**PATH /Users/leonardobusato/Documents/AstonCloud-final/astoncloud/resources/views/components/project-card.blade.php ENDPATH**/ ?>