<!doctype html>
<html lang="en">

<head>
    <!-- ================= META CONFIGURATION ================= -->
    <!-- Character encoding ensures correct text rendering -->
    <meta charset="UTF-8" />

    <!-- Favicon shown in browser tab -->
    <link rel="icon" type="image/svg+xml" href="images/favicon.svg" />

    <!-- Responsive design for mobile and tablet scaling -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Laravel Vite asset bundling (Tailwind CSS entry point) -->
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

    <!-- ================= ICON LIBRARY ================= -->
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- Page title shown in browser tab -->
    <title>AstonCloud</title>

</head>

<!-- ================= GLOBAL LAYOUT STYLES ================= -->
<body class="bg-gray-900 text-white text-base min-h-screen flex flex-col">

    <!-- ================= NAVIGATION BAR ================= -->
    <header>
        <nav class="fixed top-0 left-0 z-50 bg-gray-900 w-full px-3 sm:px-7 py-5 border-b-2 border-fuchsia-300 flex items-center justify-between">

            <!-- ================= LOGO ================= -->
            <div class="font-bold text-md sm:text-2xl">
                <a href="/">
                    Aston<span class="bg-linear-to-r from-blue-300 to-fuchsia-300 bg-clip-text text-transparent">Cloud</span>
                </a>
            </div>

            <!-- ================= NAVIGATION LINKS ================= -->
            <ul class="flex gap-1 sm:gap-4 text-xs sm:text-sm uppercase font-bold">

                <!-- Links shown only when user is authenticated -->
                <?php if(auth()->guard()->check()): ?>
                    <li>
                        <a href="/projects/manage" class="hover:text-fuchsia-300">
                            Edit Projects
                        </a>
                    </li>

                    <!-- Logout button (form) -->
                    <li>
                        <form action="/logout" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="uppercase hover:text-fuchsia-300">
                                Log Out
                            </button>
                        </form>
                    </li>

                <!-- Links shown when user is not authenticated -->
                <?php else: ?>
                    <li>
                        <a href="/users/register" class="hover:text-fuchsia-300">
                            Register
                        </a>
                    </li>
                    <li>
                        <a href="/users/login" class="hover:text-fuchsia-300">
                            Login
                        </a>
                    </li>
                <?php endif; ?>

            </ul>

            <!-- ================= PRIMARY ACTION BUTTON ================= -->
            <!-- Button for user action to create a new project  -->
            <div>
                <a href="/projects/create">
                    <button class="px-2 sm:px-4 py-1 sm:py-2 rounded-xl border-3 border-fuchsia-300 font-bold bg-gray-600 hover:bg-fuchsia-300 hover:text-gray-800 transition-colors">
                        Post!
                    </button>
                </a>
            </div>

        </nav>
    </header>

    <!-- ================= MAIN CONTENT AREA ================= -->
    <main class="flex-1">

        <!-- ================= SUCCESS MESSAGE ================= -->
        <!-- Display flash messages after create/update/delete actions -->
        <?php if(session()->has('success')): ?>
            <div class="w-fit mx-auto text-center bg-green-300 mt-30 text-green-900 p-3 rounded">
                <p><?php echo e(session('success')); ?></p>
            </div>
        <?php endif; ?>

        <!-- Page-specific content displayed here -->
        <?php echo $__env->yieldContent('content'); ?>

    </main>

    <!-- ================= FOOTER ================= -->
    <footer class="text-center text-sm mt-15 py-5 border-t-2 border-fuchsia-300">

        <!-- Copyright -->
        <p>© 2026 AstonCloud · SUN: 250438778</p>

        <!-- Links -->
        <p>
            <a href="mailto:250438778@aston.ac.uk">Email</a> ·
            <a href="https://www.linkedin.com/in/leonardo-busato-71603328b"
               target="_blank" rel="noopener">LinkedIn</a> ·
            <a href="https://github.com/LeonardoB76"
               target="_blank" rel="noopener">GitHub</a>
        </p>

    </footer>

</body>
</html><?php /**PATH /Users/leonardobusato/Documents/AstonCloud-final/astoncloud/resources/views/layout.blade.php ENDPATH**/ ?>